package bugged_032_schwabalta;



import java.util.Scanner;
public class Bugged_032_SchwabAlta {
    public static void main(String[] args){ 

        
        Scanner keyboard = new Scanner(System.in);
        String doAgain = "yes";
        
        while ("yes".equals(doAgain)){
        int whichOne = meau(keyboard);
        if (whichOne == 0){
           double eurosPerDollar=0, dollars=0, grossEuros, rate=0, fee=0, netEuros=0;
           dollars = DollarsGet(dollars, keyboard);
           eurosPerDollar = RateGetDollarToEuros(eurosPerDollar, keyboard);
           grossEuros = CalGrossEuros(dollars, eurosPerDollar, keyboard);
           DisplayExchangeDollarToEuros(dollars, grossEuros);
           rate = FeeRateGetDollarToEuros(rate, keyboard);
           fee = CalFeeDollarToEuros(grossEuros, rate, fee);
           netEuros = CalNetEuros(grossEuros, fee, netEuros);
           DisplayDollarsToEuros( dollars, eurosPerDollar, grossEuros, rate, fee, netEuros);
           System.out.print("Would you like to run the program again? Enter yes or no: ");
           doAgain = keyboard.next();
           
           
        }
        else{
           double dollarPerEuros=0, euros=0, grossDollar, rate=0, fee=0, netDollar=0;
           euros = EurosGet(euros, keyboard);
           dollarPerEuros = RateGetEurosToDollar(dollarPerEuros, keyboard);
           grossDollar = CalGrossDollar(euros, dollarPerEuros, keyboard);
           DisplayExchangeEurosToDollar(euros, grossDollar);
           rate = FeeRateGetEurosToDollar(rate, keyboard);
           fee = CalFeeEurosToDollar(grossDollar, rate, fee);
           netDollar = CalNetDollar(grossDollar, fee, netDollar);
           DisplayEurosToDollars( euros, dollarPerEuros, grossDollar, rate, fee, netDollar);
           System.out.print("Would you like to run the program again? Enter yes or no: ");
           doAgain = keyboard.next();
            
        }
        }
   
              
        
    }  
    
    public static int meau(Scanner keyboard) {
        
        int pick;
        System.out.println("Welcome to the Money Converter.\n");
        System.out.println("Would you like to convert Dollars to Euros or  Euros to Dollars?");
        System.out.println("1. Dollars to Euros\n2. Euros to Dollars ");
        System.out.print("Enter number: ");
        pick =  keyboard.nextInt();
        if (pick == 1) {
            return 0;
        }
        else {
            return 1;
        }
        
    }
    public static double DollarsGet( double dollars, Scanner keyboard) {
        System.out.print("How many dollars do you want to convert? ");        
        dollars = keyboard.nextDouble();        
        return  dollars;
    }
    public static double RateGetDollarToEuros(double eurosPerDollar, Scanner keyboard){
        System.out.print("What is the euros-per-dollar exchange rate? ");        
        eurosPerDollar = keyboard.nextDouble();  
        return  eurosPerDollar;
    }
    public static double CalGrossEuros(double dollars,double eurosPerDollar,Scanner keyboard){
        double grossEuros;
        grossEuros = dollars * eurosPerDollar;   
        return grossEuros;
    }
    public static void DisplayExchangeDollarToEuros(double dollars, double grossEuros){
        System.out.println(dollars + " Dollars => " + grossEuros + " Gross Euros.");
    }
    public static double FeeRateGetDollarToEuros(double rate, Scanner keyboard){
        System.out.print("\nWhat is the euros-per-dollar Fee Percentage % ? ");  
        rate = keyboard.nextDouble(); 
        return rate;
    }
    public static double CalFeeDollarToEuros(double grossEuros, double rate, double fee){
        fee = grossEuros * (rate / 100);
        return fee;
    }
    public static double CalNetEuros(double grossEuros, double fee, double netEuros){
        netEuros = grossEuros - fee;
        return netEuros;
    }
    public static void DisplayDollarsToEuros(double dollars, double eurosPerDollar, double grossEuros, double rate, double fee,double netEuros){
        System.out.println(dollars + " \tDollars\n " + 
                eurosPerDollar + " \tEuros Per Dollar Exchange Rate\n" +
                grossEuros + " \tGross Euros\n" +
                rate + " \tFee Percentage %\n" +
                fee + " \tFee in Euros\n" +
                netEuros + " \tNet Euros\n");  
    }
        
    
    public static double EurosGet( double euros, Scanner keyboard) {
        
        System.out.print("How many Euros do you want to convert? ");        
        euros = keyboard.nextDouble();        
        return  euros;
    }
    public static double RateGetEurosToDollar(double dollarPerEuros, Scanner keyboard){
        System.out.print("What is the dollar-per-Euro exchange rate? ");        
        dollarPerEuros = keyboard.nextDouble();  
        return  dollarPerEuros;
    }
    public static double CalGrossDollar(double euros,double dollarPerEuros,Scanner keyboard){
        double grossDollar;
        grossDollar = euros * dollarPerEuros;   
        return grossDollar;
    }
    public static void DisplayExchangeEurosToDollar(double euros, double grossDollar){
        System.out.println(euros + " Euros => " + grossDollar + " Gross Dollars.");
    }
    public static double FeeRateGetEurosToDollar(double rate, Scanner keyboard){
        System.out.print("\nWhat is the dollar-per-Euro Fee Percentage % ? ");  
        rate = keyboard.nextDouble(); 
        return rate;
    }
    public static double CalFeeEurosToDollar(double grossEuros, double rate, double fee){
        fee = grossEuros * (rate / 100);
        return fee;
    }
    public static double CalNetDollar(double grossDollar, double fee, double netDollar){
        netDollar = grossDollar - fee;
        return netDollar;
    }
    public static void DisplayEurosToDollars(double euros, double dollarPerEuros, double grossDollar, double rate, double fee,double netDollar){
        System.out.println(euros + " \tEuros\n " + 
                dollarPerEuros + " \tDollar Per Euros Exchange Rate\n" +
                grossDollar + " \tGross Dollar\n" +
                rate + " \tFee Percentage %\n" +
                fee + " \tFee in Euros\n" +
                netDollar + " \tNet Euros\n");  
    }
         
        
    }
    
    
    

