package bugged_032_schwabalta;



import java.util.Scanner;
public class Bugged_032_SchwabAlta {
    public static void main(String[] args){ 

        double eurosPerDollar, dollars, grossEuros, rate, fee, netEuros;
        Scanner keyboard = new Scanner(System.in);
        
        int whichOne = meau(keyboard);
        if (whichOne == 0){
          eurosPerDollar, dollars, grossEuros, rate, fee, netEuros = DollarsToEuros(eurosPerDollar, dollars, grossEuros, rate, fee, netEuros, keyboard);
        }
        else{
           eurosPerDollar, dollars, grossEuros, rate, fee, netEuros = EurosToDollars(eurosPerDollar, dollars, grossEuros, rate, fee, netEuros, keyboard);
            
        }
   
        System.out.println(dollars + " \tDollars\n " + 
                eurosPerDollar + " \tEuros Per Dollar Exchange Rate\n" +
                grossEuros + " \tGross Euros\n" +
                rate + " \tFee Percentage %\n" +
                fee + " \tFee in Euros\n" +
                netEuros + " \tNet Euros\n");        
        
    }  
    
    public static int meau(Scanner keyboard) {
        
        int pick;
        System.out.print("Welcome to the Money Converter.\n");
        System.out.print("Would you like to convert Dollars to Euros or  Euros to Dollars?");
        System.out.print("1. Dollars to Euros \n 2.Euros to Dollars \n ");
        pick =  keyboard.nextInt();
        if (pick == 1) {
            return 0;
        }
        else {
            return 1;
        }
        
    }
    public static double DollarsToEuros(double eurosPerDollar, double dollars, double grossEuros, double rate, double fee, double netEuros, Scanner keyboard) {
        System.out.print("How many dollars do you want to convert? ");        
        dollars = keyboard.nextDouble();        
        System.out.print("What is the euros-per-dollar exchange rate? ");        
        eurosPerDollar = keyboard.nextDouble();        
        grossEuros = dollars * eurosPerDollar;        
        System.out.println(dollars + " Dollars => " + grossEuros + " Gross Euros.");
        System.out.print("\nWhat is the euros-per-dollar Fee Percentage % ? ");  
        rate = keyboard.nextDouble(); 
        fee = grossEuros * (rate / 100);
        netEuros = grossEuros - fee;
        return eurosPerDollar, dollars, grossEuros, rate, fee, netEuros;
        
    }
    public static double EurosToDollars(double eurosPerDollar, double dollars, double grossEuros, double rate, double fee, double netEuros, Scanner keyboard) {
        System.out.print("How many dollars do you want to convert? ");        
        dollars = keyboard.nextDouble();        
        System.out.print("What is the euros-per-dollar exchange rate? ");        
        eurosPerDollar = keyboard.nextDouble();        
        grossEuros = dollars * eurosPerDollar;        
        System.out.println(dollars + " Dollars => " + grossEuros + " Gross Euros.");
        System.out.print("\nWhat is the euros-per-dollar Fee Percentage % ? ");  
        rate = keyboard.nextDouble(); 
        fee = grossEuros * (rate / 100);
        netEuros = grossEuros - fee;
        
    }
    }
    }

